# Help

## Running the tests

Write your code in the file `custom_set.go`.

To run the tests run the command `go test` from within this directory.

- [How to Write Go Code](https://golang.org/doc/code.html)
- [Effective Go](https://golang.org/doc/effective_go.html)
- [Go Resources](http://golang.org/help)